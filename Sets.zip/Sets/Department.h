#include <string>

using namespace std;

class Department{
public:
	Department(string name, string id) :name(name), id(id){}

private:
	string name;
	string id;

};